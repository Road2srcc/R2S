<?php
// clear-cache.php - Run once after deployment, then DELETE this file!
header("Content-Type: text/plain");
echo "Clearing Laravel caches...\n\n";

$commands = [
    "php ../artisan view:clear",
    "php ../artisan cache:clear", 
    "php ../artisan config:clear",
    "php ../artisan route:clear",
];

foreach ($commands as $cmd) {
    echo "Running: $cmd\n";
    echo shell_exec($cmd) . "\n";
}

echo "\n✓ All caches cleared!\n";
echo "\n⚠️ IMPORTANT: Delete this file (clear-cache.php) now for security!";
